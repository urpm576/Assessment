package com.assessment;

import java.util.List;
import java.util.Map;

import io.restassured.*;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.response.*;
import io.restassured.specification.RequestSpecification;
import io.restassured.path.json.JsonPath;
@SuppressWarnings (value="unchecked")

/**
 * This is the APICall class to call the API and 
 * get the capital's of the Country based on Name or Code according to the user input.
 */
public class APICall {
    
    Response res;
    
    static RequestSpecification getCommonSpec(){
        RequestSpecBuilder builder = new RequestSpecBuilder();
        builder.setBaseUri("https://restcountries.com");
        builder.setBasePath("/v3.1");
        
        RequestSpecification reqSpec = builder.build();
        return reqSpec;
    }
    public void getCapitalByCode(String code){
        res = RestAssured
                        .given().log().uri()
                        .spec(getCommonSpec())
                        .when()
                        .get("/alpha/"+code);
        if(res.getStatusCode()==400){
            System.out.println("Invalid input provided.");
        }else if(res.getStatusCode()==404){
            System.out.println("Data not found for the given input.");
        }else{
            printCapitals(res);
        }
    }
    public void getCapitalByName(String name){
        
        res = RestAssured
                        .given().log().uri()
                        .spec(getCommonSpec())
                        .queryParam("fullText", true)
                        .when()
                        .get("/name/"+name);
        if(res.getStatusCode()==400){
            System.out.println("Invalid input provided.");
        }else if(res.getStatusCode()==404){
            System.out.println("Data not found for the given input.");
        }else{
            printCapitals(res);
        }
    }

    public void printCapitals(Response res){
        JsonPath country = res.jsonPath();
            List<Map<Object,Object>> countries = country.get();
            for(int i=0;i<countries.size();i++){
                String countryName = ((Map<String,Object>) countries.get(i).get("name")).get("common").toString();
                System.out.println("Capitals of the Country " + countryName + " is = " + countries.get(i).get("capital"));    
            }
    }
}
