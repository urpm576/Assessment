package com.assessment;
import java.util.Scanner;

import org.apache.commons.lang3.math.NumberUtils;

/**
 * Hello world!
 *
 */
public class Assessment 
{
    public static void main(String[] args) {
        APICall ap = new APICall();
        String input;
        Scanner s = new Scanner(System.in);
        while (true) {
            System.out.println("\nEnter 1 - Get Capitals by Country name");
            System.out.println("Enter 2 - Get Capitals by Country code");
            System.out.println("Enter 3 to Exit");
            System.out.print("\nPlease select any Option = ");
            String opt = s.nextLine();
            if(opt.isEmpty() || !NumberUtils.isParsable(opt)){
                opt = "0";
            }
            switch (Integer.parseInt(opt)) {
                case 1:
                    System.out.print("Please enter the country Name = ");
                    input= s.nextLine();
                    System.out.println("You have entered Country Name as = "+input);
                    ap.getCapitalByName(input);
                    break;

                case 2:
                    System.out.print("Please enter the country Code = ");
                    input = s.nextLine();
                    System.out.println("You have entered Country Code as = "+input);
                    ap.getCapitalByCode(input);
                    break;

                case 3:
                    s.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Please enter valid option:");
            }
        }
    }
}
